#ifndef __bootmenu_ui_c__
#define __bootmenu_ui_c__
#ifdef __cplusplus
extern "C" {
#endif

#include "common.h"

byte bootmenu_haltreboot=0;

void homelist_onclick(LIBAROMA_CONTROLP list){
	LIBAROMA_CTL_LIST_ITEMP item = libaroma_ctl_list_get_touched_item(list);
	if (!item) return;
	switch (item->id){
		case ID_HOMELIST_DROID:
			break;
		case ID_HOMELIST_RECV:
			break;
		case ID_HOMELIST_FILEMGR:
			bootmenu_filemgr_loadpath(strdup("/"));
			//bootmenu_bar_update(bootmenu_fm()->cwd, NULL, LIBAROMA_CTL_BAR_ICON_DRAWER_TO_ARROW);
			break;
		case ID_HOMELIST_SETT:
			libaroma_ctl_fragment_set_active_window(fragctl, ID_SETTFRAG, 0, 400, 0, NULL, NULL, NULL);
			bootmenu_bar_update("Settings", NULL, LIBAROMA_CTL_BAR_ICON_DRAWER_TO_ARROW);
			break;
		case ID_HOMELIST_REBOOT:
			bootmenu_haltreboot=1;
			winmain->onpool=0;
			break;
		case ID_HOMELIST_PWOFF:
			bootmenu_haltreboot=2;
			winmain->onpool=0;
			break;
		case ID_HOMELIST_EXIT:
			winmain->onpool=0;
			/* send message to main window in order to exit */
			break;
	}
}
	
byte bootmenu_home_init(word bgcolor, word fillcolor){
	/* initialize appbar icon as drawer */
	libaroma_ctl_bar_set_icon(appbar, NULL, 0, LIBAROMA_CTL_BAR_ICON_DRAWER, 0);
	/* load some icons */
	LIBAROMA_CANVASP 
		recovery_cv=libaroma_image_uri("res:///icons/twrp.png"),
		settings_cv=libaroma_image_uri("res:///icons/settings.png"),
		reboot_cv=libaroma_image_uri("res:///icons/reboot.png"),
		shutdown_cv=libaroma_image_uri("res:///icons/shutdown.png"),
		exit_cv=libaroma_image_uri("res:///icons/exit.png");
	if (!settings_cv || !recovery_cv || !reboot_cv || !shutdown_cv)
		return 0;
	
	/* fill icons */
	libaroma_canvas_fillcolor(settings_cv, fillcolor);
	libaroma_canvas_fillcolor(recovery_cv, fillcolor);
	libaroma_canvas_fillcolor(reboot_cv, fillcolor);
	libaroma_canvas_fillcolor(shutdown_cv, fillcolor);
	libaroma_canvas_fillcolor(exit_cv, fillcolor);
	
	/* populate home fragment */
	homelist=libaroma_ctl_list(homefrag, ID_HOMELIST, 0, 0, LIBAROMA_SIZE_FULL, LIBAROMA_SIZE_FULL, 0, 0, bgcolor, LIBAROMA_CTL_LIST_WITH_SHADOW);
	if (!homelist) return 0;
	libaroma_listitem_caption(homelist, 0, "SYSTEM", -1);
	libaroma_listitem_menu(homelist, ID_HOMELIST_DROID, "Android", NULL, libaroma_image_uri("res:///icons/droid.png"), 	LIBAROMA_LISTITEM_WITH_SEPARATOR|LIBAROMA_LISTITEM_SEPARATOR_TEXTALIGN|LIBAROMA_LISTITEM_MENU_FREE_ICON, -1);
	libaroma_listitem_menu(homelist, ID_HOMELIST_RECV, "Recovery", NULL, recovery_cv, LIBAROMA_LISTITEM_MENU_FREE_ICON, -1);
	libaroma_listitem_caption(homelist, 0, "TOOLS", -1);
	libaroma_listitem_menu(homelist, ID_HOMELIST_FILEMGR, "Open ramdisk", NULL, libaroma_image_uri("res:///icons/filemgr.png"), LIBAROMA_LISTITEM_WITH_SEPARATOR|LIBAROMA_LISTITEM_SEPARATOR_TEXTALIGN|LIBAROMA_LISTITEM_MENU_FREE_ICON, -1);
	libaroma_listitem_menu(homelist, ID_HOMELIST_SETT, "Settings", NULL, settings_cv, LIBAROMA_LISTITEM_MENU_FREE_ICON, -1);
	libaroma_listitem_caption(homelist, 0, "POWER", -1);
	libaroma_listitem_menu(homelist, ID_HOMELIST_REBOOT, "Reboot", NULL, reboot_cv, LIBAROMA_LISTITEM_WITH_SEPARATOR|LIBAROMA_LISTITEM_SEPARATOR_TEXTALIGN|LIBAROMA_LISTITEM_MENU_FREE_ICON, -1);
	libaroma_listitem_menu(homelist, ID_HOMELIST_PWOFF, "Power off", NULL, shutdown_cv, LIBAROMA_LISTITEM_WITH_SEPARATOR|LIBAROMA_LISTITEM_SEPARATOR_TEXTALIGN|LIBAROMA_LISTITEM_MENU_FREE_ICON, -1);
	libaroma_listitem_menu(homelist, ID_HOMELIST_EXIT, "Exit", NULL, exit_cv, LIBAROMA_LISTITEM_WITH_SEPARATOR|LIBAROMA_LISTITEM_SEPARATOR_TEXTALIGN|LIBAROMA_LISTITEM_MENU_FREE_ICON, -1);
	/* set list click handler */
	libaroma_control_set_onclick(homelist, &homelist_onclick);
	return 1;
}

byte bootmenu_ui(){
	winmain=libaroma_window(NULL, 0, 0, LIBAROMA_SIZE_FULL, LIBAROMA_SIZE_FULL);
	//libaroma_ctl_button(win, 2, 0, 0, LIBAROMA_SIZE_FULL, 60, "Close", LIBAROMA_CTL_BUTTON_RAISED, RGB(FFFFFF));
	
	/* create primary controls */
	appbar = libaroma_ctl_bar(winmain, 1, 0, 0, LIBAROMA_SIZE_FULL, 56, "Bootmenu", RGB(009385), RGB(FFFFFF));
	fragctl = libaroma_ctl_fragment(winmain, ID_FRAGCTL, 0, 56, LIBAROMA_SIZE_FULL, LIBAROMA_SIZE_FULL);
	/* create home fragment */
	homefrag = libaroma_ctl_fragment_new_window(fragctl, ID_HOMEFRAG);
	/* create further fragments */
	settfrag = libaroma_ctl_fragment_new_window(fragctl, ID_SETTFRAG);
	filemfrag = libaroma_ctl_fragment_new_window(fragctl, ID_FILEMFRAG);
	filesfrag = libaroma_ctl_fragment_new_window(fragctl, ID_FILESFRAG);
	/* call individual init routines */
	if (!bootmenu_home_init(RGB(FFFFFF), RGB(0)))
		goto rip1;
	if (!bootmenu_filemgr_init(RGB(FFFFFF)))
		goto rip1;
	
	/* set home as active window */
	libaroma_ctl_fragment_set_active_window(fragctl, ID_HOMEFRAG, 0, 0, 0, NULL, NULL, NULL);
	/* show main window */
	libaroma_window_anishow(winmain, 12, 400);
	winmain->onpool=1;
	do {
		LIBAROMA_MSG msg;
		dword command	= libaroma_window_pool(winmain,&msg);
		byte cmd		= LIBAROMA_CMD(command);
		word id			= LIBAROMA_CMD_ID(command);
		byte param		= LIBAROMA_CMD_PARAM(command);
		if (msg.msg==LIBAROMA_MSG_EXIT)
			winmain->onpool=0;
		if (cmd==LIBAROMA_CMD_CLICK){
			if (id==ID_APPBAR && param==1){ /* arrow/drawer touched */
				if (libaroma_ctl_fragment_get_active_window_id(fragctl) != ID_HOMEFRAG){
					libaroma_ctl_fragment_set_active_window(fragctl, ID_HOMEFRAG, 0, 400, 0, NULL, NULL, NULL);
					libaroma_ctl_bar_set_tools(appbar, NULL, 0);
					bootmenu_bar_update("Bootmenu", NULL, LIBAROMA_CTL_BAR_ICON_ARROW_TO_DRAWER);
					/* set icon */
				continue;
				}
			}
			switch (libaroma_ctl_fragment_get_active_window_id(fragctl)){
				case ID_FILEMFRAG:
				case ID_FILESFRAG:{
					if (param==ID_APPBAR_UP){ /* title touched */
						bootmenu_filemgr_goup();
					}
				} break;
			}
		}
	} while(winmain->onpool);
	
	/* handle onclose free */
	switch (libaroma_ctl_fragment_get_active_window_id(fragctl)){
		case ID_FILEMFRAG:
		case ID_FILESFRAG:{
			bootmenu_filemgr_exit();
		} break;
	}
	
	libaroma_window_aniclose(winmain, 12, 400);
	return 0;
rip1:
	libaroma_window_free(winmain);
	return 1;
}

byte bootmenu_bar_update(char *title, char *subtitle, byte iconflag){
	/* set title/subtitle */
	libaroma_ctl_bar_set_title(appbar, title, 0);
	libaroma_ctl_bar_set_subtitle(appbar, subtitle, 0);
	
	if (iconflag) /* pass 0 to not update icon */
		libaroma_ctl_bar_set_icon(appbar, NULL, 0, iconflag, 0);
	/* update now */
	libaroma_ctl_bar_update(appbar);
	return 1;
}

#ifdef __cplusplus
}
#endif
#endif /* __bootmenu_ui_c__ */  
