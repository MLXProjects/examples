#include <dirent.h> 
#include "statusbar.c"
#include "utils.c"
#include "navbar.c"
#include "filemgr.c"